"""
checker.py — port langsung dari logika Tool.bat (Mogaly / t.me/unwaits)

Aslinya di batch:

    curl -s https://api.mojang.com/users/profiles/minecraft/%%M > mclogs.txt
    find /i "name" mclogs.txt >nul
    if errorlevel 1 ( available ) else ( taken )

Jadi aturannya cuma satu: kalau body response mengandung kata "name"
(case-insensitive) berarti nama TERPAKAI, kalau tidak ada berarti AVAILABLE.

Modul ini melakukan hal yang sama di Python, tanpa retry berlebihan, tanpa
header aneh-aneh (User-Agent curl sama seperti batch), supaya perilakunya
identik dengan Tool.bat dan tidak gampang kena limit.
"""

import threading
import time
from enum import Enum
from typing import Callable, Dict, List, Optional

import requests

# Endpoint yang dipakai Tool.bat
MOJANG_URL = "https://api.mojang.com/users/profiles/minecraft/{name}"

# Notifikasi saat tersedia
NAMEMC_URL = "https://namemc.com/search?q={name}"


class NameStatus(Enum):
    AVAILABLE = "AVAILABLE"
    TAKEN = "TAKEN"
    RATE_LIMITED = "RATE_LIMITED"
    ERROR = "ERROR"
    UNKNOWN = "UNKNOWN"


class CheckResult:
    def __init__(self, name: str, status: NameStatus, code: int = 0,
                 reason: str = "", info: Optional[dict] = None):
        self.name = name
        self.status = status
        self.code = code
        self.reason = reason
        self.info = info or {}
        self.timestamp = time.time()

    @property
    def response_code(self) -> int:
        return self.code

    def __repr__(self) -> str:
        return f"<CheckResult {self.name} {self.status.value}>"


class Checker:
    """Satu instance = satu 'curl' helper. Aman dipakai per-thread."""

    def __init__(self, delay: float = 1.0, timeout: float = 10.0,
                 proxies=None, proxy_rotate: bool = False,
                 stealth: bool = True, adaptive: bool = True,
                 max_retries: int = 1, **_ignored):
        self.delay = max(0.0, float(delay))
        self.timeout = float(timeout)
        self.proxies = proxies
        self.proxy_rotate = proxy_rotate
        self.stealth = stealth
        self.adaptive = adaptive
        self.max_retries = max(1, int(max_retries))

        self.session = requests.Session()
        # Persis seperti curl di batch: tidak ada header tambahan macam-macam
        self.session.headers.update({
            "User-Agent": "curl/7.68.0",
            "Accept": "*/*",
        })

        self._proxy_index = 0
        self._proxy_lock = threading.Lock()

        # Adaptive: naik kalau kena limit, turun pelan kalau lancar
        self._current_delay = self.delay
        self._strikes = 0

    # ------------------------------------------------------------------ #
    # Proxy
    # ------------------------------------------------------------------ #
    @staticmethod
    def _to_requests_proxies(proxy) -> Optional[dict]:
        """Terima objek Proxy, dict, atau string -> format requests."""
        if proxy is None:
            return None
        if isinstance(proxy, dict):
            return proxy
        # objek Proxy di proxy.py
        try:
            getter = getattr(proxy, "_get_proxies", None) or getattr(proxy, "as_dict", None)
            if callable(getter):
                return getter()
        except Exception:
            return None
        if isinstance(proxy, str):
            url = proxy if "://" in proxy else f"http://{proxy}"
            return {"http": url, "https": url}
        return None

    def _next_proxy(self) -> Optional[dict]:
        if not self.proxies:
            return None
        try:
            # ProxyManager (punya get_best_proxy) dipakai langsung
            if hasattr(self.proxies, "get_best_proxy"):
                return self._to_requests_proxies(self.proxies.get_best_proxy())
            seq = list(self.proxies)
        except Exception:
            return None
        if not seq:
            return None
        with self._proxy_lock:
            if not self.proxy_rotate:
                proxy = seq[0]
            else:
                proxy = seq[self._proxy_index % len(seq)]
                self._proxy_index += 1
        return self._to_requests_proxies(proxy)

    # ------------------------------------------------------------------ #
    # Inti: sama seperti `find /i "name" mclogs.txt`
    # ------------------------------------------------------------------ #
    def _is_taken(self, body: str) -> bool:
        return "name" in body.lower()

    def check(self, name: str) -> CheckResult:
        name = (name or "").strip().lower()
        if not name or not (3 <= len(name) <= 16):
            return CheckResult(name, NameStatus.ERROR, 0, "invalid name")

        url = MOJANG_URL.format(name=name)
        proxies = self._next_proxy()

        for attempt in range(self.max_retries):
            try:
                resp = self.session.get(url, timeout=self.timeout,
                                        proxies=proxies, allow_redirects=True)
                code = resp.status_code
                body = resp.text or ""

                if code == 200:
                    # aturan Tool.bat: body mengandung "name" -> taken
                    if self._is_taken(body):
                        self._on_ok()
                        return CheckResult(name, NameStatus.TAKEN, code)
                    self._on_ok()
                    return CheckResult(name, NameStatus.AVAILABLE, code)

                if code in (204, 404):
                    # CATATAN: sejak 2024 Mojang balas 404 dengan body
                    # {"path":"...", "errorMessage":"Couldn't find any profile
                    #  with name <x>"} -> body-nya mengandung kata "name".
                    # Kalau dicek substring mentah seperti batch asli, nama yang
                    # AVAILABLE jadi terbaca TAKEN. Jadi kode status didahulukan.
                    self._on_ok()
                    return CheckResult(name, NameStatus.AVAILABLE, code)

                if code in (429, 403):
                    self._on_limit()
                    return CheckResult(name, NameStatus.RATE_LIMITED, code,
                                       "rate limited" if code == 429 else "forbidden")

                if code >= 500 and attempt + 1 < self.max_retries:
                    time.sleep(1.0)
                    continue

                return CheckResult(name, NameStatus.ERROR, code, f"http {code}")

            except requests.exceptions.Timeout:
                if attempt + 1 < self.max_retries:
                    continue
                return CheckResult(name, NameStatus.ERROR, 0, "timeout")
            except requests.exceptions.ConnectionError:
                if attempt + 1 < self.max_retries:
                    time.sleep(0.5)
                    continue
                return CheckResult(name, NameStatus.ERROR, 0, "connection error")
            except Exception as exc:  # noqa: BLE001
                return CheckResult(name, NameStatus.ERROR, 0, str(exc)[:60])

        return CheckResult(name, NameStatus.ERROR, 0, "retry exhausted")

    # alias lama supaya kode lain tetap jalan
    check_name = check

    # ------------------------------------------------------------------ #
    def _on_limit(self) -> None:
        if not self.adaptive:
            return
        self._strikes += 1
        self._current_delay = min(self._current_delay * 1.6 + 0.5, 20.0)

    def _on_ok(self) -> None:
        if not self.adaptive:
            return
        self._strikes = 0
        self._current_delay = max(self.delay, self._current_delay * 0.85)

    def pause(self) -> None:
        """Jeda antar request, seperti batch yang jalan sekuensial."""
        if self.delay > 0 or self._current_delay > 0:
            time.sleep(max(self.delay, self._current_delay))


# ---------------------------------------------------------------------- #
# Helper sekuensial: persis alur Tool.bat (tanpa GUI)
# ---------------------------------------------------------------------- #
def run_file(combo_path: str, checker: Optional[Checker] = None,
             on_hit: Optional[Callable[[str], None]] = None,
             open_namemc: bool = False, stop_event: Optional[threading.Event] = None):
    """Versi Python dari loop `for /F %%M in (combo.txt)` di Tool.bat."""
    import webbrowser

    checker = checker or Checker(delay=0.5)
    hits: List[str] = []
    stop_event = stop_event or threading.Event()

    with open(combo_path, "r", encoding="utf-8", errors="ignore") as fh:
        names = [line.strip() for line in fh if line.strip()]

    for name in names:
        if stop_event.is_set():
            break
        result = checker.check(name)
        if result.status == NameStatus.AVAILABLE:
            hits.append(result.name)
            print(f"[+] {result.name}")
            if open_namemc:
                webbrowser.open(NAMEMC_URL.format(name=result.name))
            if on_hit:
                on_hit(result.name)
        else:
            print(f"[-] {result.name}")
        checker.pause()

    return hits


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("usage: python checker.py <name|combo.txt>")
        raise SystemExit(1)

    target = sys.argv[1]
    if target.lower().endswith(".txt"):
        found = run_file(target)
        print(f"\n{len(found)} available -> hits.txt")
        with open("hits.txt", "a", encoding="utf-8") as fh:
            for n in found:
                fh.write(n + "\n")
    else:
        res = Checker().check(target)
        print(f"{res.name} -> {res.status.value}")
