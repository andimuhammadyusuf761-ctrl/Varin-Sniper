"""Auto Claim module: Microsoft OAuth -> Xbox Live -> XSTS -> Minecraft API"""
import os
import json
import time
import threading
import logging
import requests
from enum import Enum
from typing import Optional, List, Dict, Any, Callable
from datetime import datetime

logger = logging.getLogger("MinecraftSniper.Claimer")

MS_OAUTH_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0"
XBL_AUTH = "https://user.auth.xboxlive.com/user/authenticate"
XSTS_AUTH = "https://xsts.auth.xboxlive.com/xsts/authorize"
MC_LOGIN = "https://api.minecraftservices.com/authentication/login_with_xbl"
MC_PROFILE = "https://api.minecraftservices.com/minecraft/profile"
MC_NAME_AVAILABILITY = "https://api.minecraftservices.com/minecraft/profile/nameavailability"
MC_NAME_CHANGE_INFO = "https://api.minecraftservices.com/minecraft/profile/namechange"

TOKEN_STORE = "ms_tokens.json"

class ClaimStatus(Enum):
    SUCCESS = "success"
    NAME_TAKEN = "name_taken"
    NOT_ELIGIBLE = "not_eligible"
    TOKEN_INVALID = "token_invalid"
    RATE_LIMITED = "rate_limited"
    ERROR = "error"
    COOLDOWN = "cooldown"

class MMCLoginError(Exception):
    pass

class MMCAccount:
    def __init__(self, email: str = "", client_id: str = "",
                 refresh_token: str = "", mc_access_token: str = "",
                 mc_token_expiry: float = 0.0, profile_name: str = ""):
        self.email = email
        self.client_id = client_id
        self.refresh_token = refresh_token
        self.mc_access_token = mc_access_token
        self.mc_token_expiry = mc_token_expiry
        self.profile_name = profile_name
        self.failed_count = 0
        self.last_used = 0.0
        self.cooldown_until = 0.0
        self.enabled = True
        self._lock = threading.Lock()
    
    def label(self) -> str:
        if self.profile_name:
            return f"{self.email} [{self.profile_name}]"
        return self.email or "Unknown"
    
    def is_valid(self) -> bool:
        if not self.enabled:
            return False
        if self.cooldown_until > time.time():
            return False
        if self.failed_count >= 5:
            return False
        return True
    
    def is_token_valid(self) -> bool:
        if not self.mc_access_token:
            return False
        return self.mc_token_expiry > time.time() + 60
    
    def mark_failed(self):
        with self._lock:
            self.failed_count += 1
            self.last_used = time.time()
            if self.failed_count >= 3:
                self.cooldown_until = time.time() + 300  # 5 min cooldown
    
    def mark_success(self):
        with self._lock:
            self.failed_count = max(0, self.failed_count - 1)
            self.last_used = time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "email": self.email,
            "client_id": self.client_id,
            "refresh_token": self.refresh_token,
            "mc_access_token": self.mc_access_token,
            "mc_token_expiry": self.mc_token_expiry,
            "profile_name": self.profile_name,
        }
    
    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "MMCAccount":
        acc = cls(
            email=d.get("email", ""),
            client_id=d.get("client_id", ""),
            refresh_token=d.get("refresh_token", ""),
            mc_access_token=d.get("mc_access_token", ""),
            mc_token_expiry=d.get("mc_token_expiry", 0.0),
            profile_name=d.get("profile_name", ""),
        )
        return acc

class ClaimResult:
    def __init__(self, name: str, account: Optional[MMCAccount], status: ClaimStatus, message: str = ""):
        self.name = name
        self.account = account
        self.status = status
        self.message = message
        self.timestamp = time.time()
    
    def __repr__(self) -> str:
        label = self.account.label() if self.account else "?"
        return f"{self.name!r} ({label}) -> {self.status.value}: {self.message}"

def load_accounts(path: str = TOKEN_STORE) -> List[MMCAccount]:
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            return [MMCAccount.from_dict(d) for d in data]
    except Exception as e:
        logger.error(f"load_accounts failed: {e}")
        return []

def save_accounts(accounts: List[MMCAccount], path: str = TOKEN_STORE) -> None:
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump([a.to_dict() for a in accounts], f, indent=2)
    except Exception as e:
        logger.error(f"save_accounts failed: {e}")

def _mc_token_from_ms(ms_access_token: str, session: requests.Session) -> Dict[str, Any]:
    hdr = {"Content-Type": "application/json", "Accept": "application/json"}
    
    r = session.post(XBL_AUTH, headers=hdr, json={
        "Properties": {
            "AuthMethod": "RPS",
            "SiteName": "user.auth.xboxlive.com",
            "RpsTicket": f"d={ms_access_token}",
        },
        "RelyingParty": "http://auth.xboxlive.com",
        "TokenType": "JWT",
    }, timeout=30)
    if r.status_code != 200:
        raise MMCLoginError(f"XBL auth failed: HTTP {r.status_code}")
    xbl = r.json()
    xbl_token = xbl["Token"]
    
    r = session.post(XSTS_AUTH, headers=hdr, json={
        "Properties": {"SandboxId": "RETAIL", "UserTokens": [xbl_token]},
        "RelyingParty": "rp://api.minecraftservices.com/",
        "TokenType": "JWT",
    }, timeout=30)
    if r.status_code != 200:
        raise MMCLoginError(f"XSTS auth failed: HTTP {r.status_code}")
    xsts = r.json()
    xsts_token = xsts["Token"]
    uhs = xsts["DisplayClaims"]["xui"][0]["uhs"]
    
    r = session.post(MC_LOGIN, headers={"Content-Type": "application/json"},
                     json={"identityToken": f"XBL3.0 x={uhs};{xsts_token}"}, timeout=30)
    if r.status_code != 200:
        raise MMCLoginError(f"MC login failed: HTTP {r.status_code}")
    return r.json()

def refresh_account_tokens(acc: MMCAccount, session: Optional[requests.Session] = None) -> bool:
    if session is None:
        from checker import Checker
        session = Checker().session
    if not acc.refresh_token or not acc.client_id:
        raise MMCLoginError(f"{acc.label()}: Missing refresh_token or client_id")
    try:
        r = session.post(f"{MS_OAUTH_URL}/token", data={
            "client_id": acc.client_id,
            "grant_type": "refresh_token",
            "refresh_token": acc.refresh_token,
            "scope": "XboxLive.signin offline_access"
        }, timeout=30)
        data = r.json()
        if "access_token" not in data:
            raise MMCLoginError(f"Refresh failed: {data.get('error', 'unknown')}")
        acc.refresh_token = data.get("refresh_token", acc.refresh_token)
        mc = _mc_token_from_ms(data["access_token"], session)
        acc.mc_access_token = mc["access_token"]
        acc.mc_token_expiry = time.time() + mc.get("expires_in", 86400) - 600
        logger.info(f"{acc.label()}: Token refreshed successfully")
        return True
    except Exception as e:
        logger.error(f"Token refresh failed for {acc.label()}: {e}")
        acc.enabled = False
        raise

def ensure_valid_token(acc: MMCAccount, session: Optional[requests.Session] = None) -> bool:
    if acc.is_token_valid():
        return True
    if acc.refresh_token and acc.client_id:
        try:
            return refresh_account_tokens(acc, session)
        except:
            return False
    return False

def login_with_refresh_token(ms_refresh_token: str, client_id: str, email: str = "", session: Optional[requests.Session] = None) -> MMCAccount:
    if not client_id:
        raise MMCLoginError("Client ID required for refresh token login")
    acc = MMCAccount(email=email, client_id=client_id, refresh_token=ms_refresh_token)
    session = session or requests.Session()
    if refresh_account_tokens(acc, session):
        try:
            verify_mc_token(acc, session)
        except:
            pass
    return acc

def login_with_mc_token(mc_access_token: str, email: str = "") -> MMCAccount:
    acc = MMCAccount(email=email, mc_access_token=mc_access_token.strip())
    acc.mc_token_expiry = time.time() + 3600 * 23
    verify_mc_token(acc)
    return acc

def verify_mc_token(acc: MMCAccount, session: Optional[requests.Session] = None) -> str:
    session = session or requests.Session()
    r = session.get(MC_PROFILE, headers={"Authorization": f"Bearer {acc.mc_access_token}"}, timeout=30)
    if r.status_code == 401:
        raise MMCLoginError("Token invalid or expired")
    if r.status_code != 200:
        raise MMCLoginError(f"Profile check failed: HTTP {r.status_code}")
    try:
        data = r.json()
        acc.profile_name = data.get("name", "")
        return acc.profile_name
    except:
        raise MMCLoginError("Invalid profile response")

def login_with_device_code(client_id: str, email: str = "", on_prompt: Optional[Callable] = None, proxies: Optional[Dict] = None) -> MMCAccount:
    s = requests.Session()
    if proxies:
        s.proxies.update(proxies)
    
    r = s.post(f"{MS_OAUTH_URL}/devicecode", data={"client_id": client_id, "scope": "XboxLive.signin offline_access"}, timeout=30)
    if r.status_code != 200:
        raise MMCLoginError(f"Device code request failed: {r.status_code}")
    dc = r.json()
    
    msg = f"\n=== MICROSOFT LOGIN ===\n1. Open: {dc['verification_uri']}\n2. Enter code: {dc['user_code']}\n3. Login and approve\n"
    if on_prompt:
        on_prompt(msg)
    else:
        print(msg)
    
    interval = max(int(dc.get("interval", 5)), 3)
    deadline = time.time() + dc.get("expires_in", 900)
    
    while time.time() < deadline:
        time.sleep(interval)
        rr = s.post(f"{MS_OAUTH_URL}/token", data={
            "client_id": client_id,
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            "device_code": dc["device_code"]
        }, timeout=30)
        data = rr.json()
        if "access_token" in data:
            acc = MMCAccount(email=email, client_id=client_id, refresh_token=data.get("refresh_token", ""))
            mc = _mc_token_from_ms(data["access_token"], s)
            acc.mc_access_token = mc["access_token"]
            acc.mc_token_expiry = time.time() + mc.get("expires_in", 86400) - 600
            try:
                verify_mc_token(acc, s)
            except:
                pass
            return acc
        err = data.get("error")
        if err == "authorization_pending":
            continue
        elif err == "slow_down":
            interval += 2
            continue
        elif err == "authorization_declined":
            raise MMCLoginError("Login declined by user")
        elif err == "expired_token":
            raise MMCLoginError("Device code expired")
        else:
            raise MMCLoginError(f"OAuth error: {err}")
    raise MMCLoginError("Login timeout")

def get_name_change_info(acc: MMCAccount, session: Optional[requests.Session] = None) -> Dict[str, Any]:
    session = session or requests.Session()
    if not ensure_valid_token(acc, session):
        return {}
    try:
        r = session.get(MC_NAME_CHANGE_INFO, headers={"Authorization": f"Bearer {acc.mc_access_token}"}, timeout=30)
        if r.status_code == 200:
            return r.json()
    except:
        pass
    return {}

def check_name_available(acc: MMCAccount, name: str, session: Optional[requests.Session] = None) -> bool:
    session = session or requests.Session()
    if not ensure_valid_token(acc, session):
        return False
    try:
        r = session.get(f"{MC_NAME_AVAILABILITY}/{name}", headers={"Authorization": f"Bearer {acc.mc_access_token}"}, timeout=30)
        if r.status_code == 429:
            raise requests.HTTPError("Rate limited")
        if r.status_code != 200:
            return False
        return r.json().get("status", "").upper() == "AVAILABLE"
    except requests.HTTPError:
        raise
    except:
        return False

def claim_name(acc: MMCAccount, name: str, session: Optional[requests.Session] = None) -> ClaimResult:
    session = session or requests.Session()
    if not acc.is_valid():
        return ClaimResult(name, acc, ClaimStatus.TOKEN_INVALID, "Account invalid/cooldown")
    
    if not ensure_valid_token(acc, session):
        acc.mark_failed()
        return ClaimResult(name, acc, ClaimStatus.TOKEN_INVALID, "Token refresh failed")
    
    headers = {"Authorization": f"Bearer {acc.mc_access_token}", "Content-Type": "application/json"}
    
    try:
        # Pre-check
        try:
            if not check_name_available(acc, name, session):
                return ClaimResult(name, acc, ClaimStatus.NAME_TAKEN, "Pre-check: unavailable")
        except requests.HTTPError as e:
            if e.response and e.response.status_code == 429:
                return ClaimResult(name, acc, ClaimStatus.RATE_LIMITED, "429 on pre-check")
        
        # Check cooldown
        nc_info = get_name_change_info(acc, session)
        if nc_info.get("changeAllowedAt"):
            try:
                allowed_at = datetime.fromisoformat(nc_info["changeAllowedAt"].replace("Z", "+00:00"))
                if allowed_at.timestamp() > time.time():
                    remaining = int(allowed_at.timestamp() - time.time())
                    return ClaimResult(name, acc, ClaimStatus.NOT_ELIGIBLE, f"Cooldown: {remaining//3600}h {(remaining%3600)//60}m remaining")
            except:
                pass
        
        # Attempt claim
        r = session.post(MC_PROFILE, headers=headers, json={"profileName": name}, timeout=30)
        
        if r.status_code == 200:
            acc.mark_success()
            try:
                prof = session.get(MC_PROFILE, headers=headers, timeout=30)
                if prof.status_code == 200:
                    actual = prof.json().get("name", name)
                    return ClaimResult(name, acc, ClaimStatus.SUCCESS, f"Claimed as '{actual}'")
            except:
                pass
            return ClaimResult(name, acc, ClaimStatus.SUCCESS, "Successfully claimed")
        elif r.status_code == 400:
            acc.mark_failed()
            return ClaimResult(name, acc, ClaimStatus.NAME_TAKEN, "400: Taken or invalid")
        elif r.status_code == 403:
            acc.mark_failed()
            try:
                nc_info = get_name_change_info(acc, session)
                if nc_info.get("changeAllowedAt"):
                    return ClaimResult(name, acc, ClaimStatus.NOT_ELIGIBLE, "403: Name change cooldown active")
            except:
                pass
            return ClaimResult(name, acc, ClaimStatus.NOT_ELIGIBLE, "403: Not eligible/cooldown")
        elif r.status_code == 401:
            acc.mark_failed()
            return ClaimResult(name, acc, ClaimStatus.TOKEN_INVALID, "401: Token invalid")
        elif r.status_code == 429:
            acc.mark_failed()
            return ClaimResult(name, acc, ClaimStatus.RATE_LIMITED, "429: Rate limited")
        else:
            acc.mark_failed()
            return ClaimResult(name, acc, ClaimStatus.ERROR, f"HTTP {r.status_code}: {r.text[:50]}")
            
    except Exception as e:
        acc.mark_failed()
        return ClaimResult(name, acc, ClaimStatus.ERROR, f"Exception: {str(e)[:100]}")

class SmartClaimQueue:
    def __init__(self, accounts: List[MMCAccount]):
        self.accounts = accounts
        self._lock = threading.Lock()
        self._index = 0
    
    def get_next_account(self) -> Optional[MMCAccount]:
        with self._lock:
            valid_accounts = [a for a in self.accounts if a.is_valid() and a.is_token_valid()]
            if not valid_accounts:
                # Try to refresh and retry
                for a in self.accounts:
                    if a.enabled and a.refresh_token and a.client_id and a.cooldown_until < time.time():
                        try:
                            ensure_valid_token(a)
                            if a.is_token_valid():
                                valid_accounts.append(a)
                        except:
                            pass
            if not valid_accounts:
                return None
            # Round-robin
            acc = valid_accounts[self._index % len(valid_accounts)]
            self._index += 1
            return acc
    
    def get_account_count(self) -> int:
        return len([a for a in self.accounts if a.is_valid()])

if __name__ == "__main__":
    print("Use GUI (main.py) for authentication")
