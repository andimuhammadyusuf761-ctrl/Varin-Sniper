@echo off
:: MC-Sniper — proxyless checker (based on Tool.bat by Mogaly | t.me/unwaits)
:: Fix: Mojang sekarang balas 404 dengan body berisi kata "name", jadi
:: pengecekan pakai HTTP status code (curl -w), bukan cari kata "name" saja.
chcp 65001>nul
setlocal enabledelayedexpansion

:retry
cls
title Minecraft Name Checker
echo.
echo  █▀▄▀█ █ █▄ █ █▀▀ █▀▀ █▀█ ▄▀█ █▀▀ ▀█▀   █▄ █ ▄▀█ █▀▄▀█ █▀▀   █▀▀ █ █ █▀▀ █▀▀ █▄▀ █▀▀ █▀█
echo  █ ▀ █ █ █ ▀█ ██▄ █▄▄ █▀▄ █▀█ █▀    █    █ ▀█ █▀█ █ ▀ █ ██▄   █▄▄ █▀█ ██▄ █▄▄ █ █ ██▄ █▀▄
echo.
echo  Drag the combo file (.txt) to this console
echo.
set /p combo="[?] Path: "
if not exist "%combo%" echo  [-] File not found & pause>nul & goto retry
echo  [+] Combo loaded
set /p namemc="[?] Open NameMC on hit? (Y/N): "
echo  [+] Starting
echo.

if exist hits.txt del hits.txt /q

for /F "usebackq tokens=*" %%M in ("%combo%") do (
    curl -s -o "%temp%\mclogs.txt" -w "%%{http_code}" https://api.mojang.com/users/profiles/minecraft/%%M > "%temp%\mccode.txt"
    set "CODE="
    set /p CODE=<"%temp%\mccode.txt"
    if "!CODE!"=="200" (
        echo  [-] %%M
    ) else if "!CODE!"=="204" (
        echo  [+] %%M
        echo %%M>>hits.txt
        if /i "%namemc%"=="Y" start "" https://namemc.com/search?q=%%M
    ) else if "!CODE!"=="404" (
        echo  [+] %%M
        echo %%M>>hits.txt
        if /i "%namemc%"=="Y" start "" https://namemc.com/search?q=%%M
    ) else (
        echo  [!] %%M  ^(HTTP !CODE! - rate limited / error^)
    )
)

echo.
echo  Valid names saved in hits.txt
pause>nul
exit
